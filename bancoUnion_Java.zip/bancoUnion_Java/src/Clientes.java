/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Clientes {
    public int id; // Identificador único del cliente
    public String nombre; // Nombre del Cliente
    public String apellido; // Apellido del Cliente
    public String direccion; // Dirección del Cliente
    public int telefono; // Número Telefónico
    public String correo; // Correo Electrónico del Cliente
    public  String estado; // Estado del Cliente --> Activo/Inactivo
    public int fecha_registro; // Fecha de Registro del Cliente
    public int ultima_actividad; // Ultima Actividad del Cliente

    // Constructor para inicializar el objeto
    public Clientes (int id, String nombre, String apellido, String direccion, int telefono, String correo, String estado, int fecha_registro, int ultima_actividad){
        this.id=id;
        this.nombre=nombre;
        this.apellido=apellido;
        this.direccion=direccion;
        this.telefono=telefono;
        this.correo=correo;
        this.estado=estado;
        this.fecha_registro=fecha_registro;
        this.ultima_actividad=ultima_actividad;
    }
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id=id;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public String getApellido(){
        return apellido;
    }
    
    public void setApellido(String apellido){
        this.apellido=apellido;
    }
    
    public String getDireccion(){
        return direccion;
    }
    
    public void setDireccion(String direccion){
        this.direccion=direccion;
    }
    
    public int getTelefono(){
        return telefono;
    }
    
    public void setTelefono(int telefono){
        this.telefono=telefono;
    }
    
    public String getCorreo(){
        return correo;
    }
    
    public void setCorreo(String correo){
        this.correo=correo;
    }
    
    public String getEstado(){
        return estado;
    }
    
    public void setEstado(String estado){
        this.estado=estado;
    }
    
    public int getFecha_registro(){
        return fecha_registro;
    }
    
    public void setFecha_registro(int fecha_registro){
        this.fecha_registro=fecha_registro;
    }
    
    public int getUltima_actividad(){
        return ultima_actividad;
    }
    
    public void setUltima_actividad(int ultima_actividad){
        this.ultima_actividad=ultima_actividad;
    }
    
    @Override
    public String toString(){
        return "Cliente{" + "ID: " + id + ", Nombre: " + nombre + '\'' + ", Apellido: " 
                + apellido + ", Direccion: " + direccion + '\'' + ", Telefono: " 
                + telefono + '\'' + ", Correo: " + correo + '\'' + ", Estado: " 
                + estado + '\'' + ", Fecha_Registro: " + fecha_registro + '\'' 
                + ", Ultima_Actividad: " + ultima_actividad;
    }         
}


    
