/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Transacciones {
    public int id; // Identificador único de cada Transacción
    public int id_cuenta; // Identificador único de cada cuenta
    public String tipo; // Tipo de Transacción
    public float monto; // Monto de la Transacción
    public int fecha; // Fecha de la Transacción
    public String referencia; // Referencia de la Transacción
    public float saldo_anterior; // Saldo Anterior
    public float saldo_nuevo; // Saldo Nuevo
    public String estado; // Estado
   
    // Constructor para inicializar el objeto
    public Transacciones (int id, int id_cuenta, String tipo, float monto, int fecha, String referencia, float saldo_anterior,
            float saldo_nuevo, String estado){
        this.id=id;
        this.id_cuenta=id_cuenta;
        this.tipo=tipo;
        this.monto=monto;
        this.fecha=fecha;
        this.referencia=referencia;
        this.saldo_anterior=saldo_anterior;
        this.saldo_nuevo=saldo_nuevo;
        this.estado=estado;     
    }
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id=id;
    }
    
    public int getId_Cuenta(){
        return id_cuenta;
    }
    
    public void setId_Cuenta(int id_cuenta){
        this.id_cuenta=id_cuenta;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public void setTipo(String tipo){
        this.tipo=tipo;
    }
    
    public float getMonto(){
        return monto;
    }
    
    public void setMonto(float monto){
        this.monto=monto;
    }
    
    public int getFecha(){
        return fecha;
    }
    
    public void setFecha(int fecha){
        this.fecha=fecha;
    }
    
    public String getReferencia(){
        return referencia;
    }
    
    public void setReferencia(String referencia){
        this.referencia=referencia;
    }
    
    public float getSaldoA(){
        return id_cuenta;
    }
    
    public void setSaldoA(float saldo_anterior){
        this.saldo_anterior=saldo_anterior;
    }
    
    public float getSaldoN(){
        return saldo_nuevo;
    }
    
    public void setSaldoN(float saldo_nuevo){
        this.saldo_nuevo=saldo_nuevo;
    }
    
    public String getEstado(){
        return estado;
    }
    
    public void setEstado(String estado){
        this.estado=estado;
    }
    
    @Override
    public String toString(){
        return "Transacción{" + "ID: " + id + ", ID_Cuenta: " + id_cuenta + '\'' + ", Tipo: " 
                + tipo + ", Monto: " + monto + '\'' + ", Fecha: " 
                + fecha + '\'' + ", Referencia: " + referencia + '\'' + ", Saldo_Anterior: " 
                + saldo_anterior + '\'' + ", Saldo_Nuevo: " + saldo_nuevo + '\'' 
                + ", Estado: " + estado;
    }
}
