/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bancounion_java;

/**
 *
 * @author camper
 */
public class BancoUnion_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("*************************");
        System.out.println("BIENVENIDO A BANCO UNIÓN");
        System.out.println("*************************");
        System.out.println("¿En qué te podemos ayudar?");
        System.out.println("");
    }
    
}
