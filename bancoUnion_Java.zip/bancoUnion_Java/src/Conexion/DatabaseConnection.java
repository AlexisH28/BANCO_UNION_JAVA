/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static DatabaseConnection instancia; // Instancia única --> Aplicación del Patrón de Diseño Singleton
    private Connection conexion;

    // Constructor privado para evitar instanciación directa 
    private DatabaseConnection() {
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/banco_union", "campus2023", "campus2023");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Método para obtener la instancia única
    public static synchronized DatabaseConnection getInstance() {
        if (instancia == null) {
            instancia = new DatabaseConnection();
        }
        return instancia;
    }  
}


