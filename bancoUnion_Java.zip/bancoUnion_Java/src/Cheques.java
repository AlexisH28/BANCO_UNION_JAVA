/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Cheques {
    public int id; // Identificador único de cheque
    public String numero_cheque; // Número Cheque
    public int id_cuenta; // Indentificador único de la cuenta
    public String beneficiario; // Beneficiario del Cheque
    public float monto; // Monto del Cheque
    public String monto_letras; // Monto Letras del Cheque
    public String prioridad; // Prioridad del Cheque
    public String firma_digital; // Firma Digital del Cheque
    public String estado; // Estado del Cheque
    public String razon_rechazo; // Razon rechazo del Cheque
    public int fecha_emision; // Fecha de la emision del Cheque
    public int fecha_proceso; // Fecha Proceso del Cheque
    public boolean cobrado; // Cobrado
    public float cuenta_saldo_momento; // Cuenta del Momento
    public int fecha_modificacion; // Fecha Modificación del Cheque
    public String usuario_modificacion; // Usuario de la Modificación del Cheque
    
    // Constructor para inicializar el objeto
    public Cheques (int id, String numero_cheque, int id_cuenta, String beneficiario, float monto, String monto_letras, String prioridad, String firma_digital, String estado, String razon_rechazo, int fecha_emision, int fecha_proceso, boolean cobrado, float cuenta_saldo_momento, int fecha_modificacion, String usuario_modificacion){
        this.id=id;
        this.numero_cheque=numero_cheque;
        this.id_cuenta=id_cuenta;
        this.beneficiario=beneficiario;
        this.monto=monto;
        this.monto_letras=monto_letras;
        this.prioridad=prioridad;
        this.firma_digital=firma_digital;
        this.estado=estado;
        this.razon_rechazo=razon_rechazo;
        this.fecha_emision=fecha_emision;
        this.fecha_proceso=fecha_proceso;
        this.cobrado=cobrado;
        this.cuenta_saldo_momento=cuenta_saldo_momento;
        this.fecha_modificacion=fecha_modificacion;                
        this.usuario_modificacion=usuario_modificacion;                
    }
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id=id;
    }
    
     public String getN_Cheque(){
        return numero_cheque;
    }
    
    public void setN_Cheque(String numero_cheque){
        this.numero_cheque=numero_cheque;
    }
    
    public int setId_Cuenta(){
        return id_cuenta;
    }
    
    public void setId_Cuenta(int id_cuenta){
        this.id_cuenta=id_cuenta;
    }
    
    public String getBenef(){
        return beneficiario;
    }
    
    public void setBenef(String beneficiario){
        this.beneficiario=beneficiario;
    }
    
    public float getMonto(){
        return monto;
    }
    
    public void setMonto(float monto){
        this.monto=monto;
    }
    
    public String getMN_Letras(){
        return monto_letras;
    }
    
    public void setMN_Letras(String monto_letras){
        this.monto_letras=monto_letras;
    }
    
    public String getPrioridad(){
        return prioridad;
    }
    
    public void setPrioridad(String prioridad){
        this.prioridad=prioridad;
    }
    
    public String getFirmaDigit(){
        return firma_digital;
    }
    
    public void setFirmaDigit(String firma_digital){
        this.firma_digital=firma_digital;
    }
    
    public String getEstado(){
        return estado;
    }
    
    public void setEstado(String estado){
        this.estado=estado;
    }
    
    public String getRazon_R(){
        return razon_rechazo;
    }
    
    public void setRazon_R(String razon_rechazo){
        this.razon_rechazo=razon_rechazo;
    }
    
    public int getFecha_E(){
        return fecha_emision;
    }
    
    public void setFecha_E(int fecha_emision){
        this.fecha_emision=fecha_emision;
    }
    
    public int getFecha_P(){
        return fecha_proceso;
    }
    
    public void setFecha_P(int fecha_proceso){
        this.fecha_proceso=fecha_proceso;
    }
    
    public boolean getCobrado(){
        return cobrado;
    }
    
    public void setCobrado(boolean cobrado){
        this.cobrado=cobrado;
    }
    
    public float getCuentaSM(){
        return cuenta_saldo_momento;
    }
    
    public void setCuentaSM(float cuenta_saldo_momento){
        this.cuenta_saldo_momento=cuenta_saldo_momento;
    }
    
    public int getFecha_M(){
        return fecha_modificacion;
    }
    
    public void setFecha_M(int fecha_modificacion){
        this.fecha_modificacion=fecha_modificacion;
    }
    
    public String getUsuario_M(){
        return usuario_modificacion;
    }
    
    public void setUsuario_M(String usuario_modificacion){
        this.usuario_modificacion=usuario_modificacion;
    }
    
    @Override
    public String toString(){
        return "Cheque{" + "ID: " + id + ", Numero_Cheque: " + numero_cheque + '\'' + ", ID_Cuenta: " 
                + id_cuenta + ", Beneficiario: " + beneficiario + '\'' + ", Monto: " 
                + monto + '\'' + ", Monto_Letras: " + monto_letras + '\'' + ", Prioridad: " 
                + prioridad + '\'' + ", Firma-Digital: " + firma_digital + '\'' 
                + ", Estado: " + estado + '\'' + ", Razon_Rechazo: " + razon_rechazo + '\'' 
                + ", Fecha_Emisión: " + fecha_emision + '\'' + ", Fecha_Proceso: " + fecha_proceso + '\'' 
                + ", Cobrado: " + cobrado + '\'' + ", Cuenta_Saldo_Momento: " + cuenta_saldo_momento + '\'' 
                + ", Fecha_Modificación: " + fecha_modificacion + '\'' + ", Usuario_Modificación: " + usuario_modificacion;
    }
    
}
