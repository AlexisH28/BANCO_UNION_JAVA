/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Cuentas {
    public int id; // Identificador único de la cuenta
    public int id_cliente; // Indentificador único del Cliente
    public String tipo; // Tipo de Cuenta
    public float saldo; // Saldo de la Cuenta
    public float limite_saldo; // Limite del Saldo de la Cuenta
    public int fecha_apertura; // Fecha de Apertura de la Cuenta
    public String estado; // Estado de la Cuenta

    // Constructor para inicializar el objeto
    public Cuentas (int id, int id_cliente, String tipo, float saldo, float limite_saldo, int fecha_apertura, String estado){
        this.id=id;
        this.id_cliente=id_cliente;
        this.tipo=tipo;
        this.saldo=saldo;
        this.limite_saldo=limite_saldo;
        this.fecha_apertura=fecha_apertura;
        this.estado=estado;
    }
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id=id;
    }
    
     public int getId_Cliente(){
        return id_cliente;
    }
    
    public void setId_Cliente(int id_cliente){
        this.id_cliente=id_cliente;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public void setTipo(String tipo){
        this.tipo=tipo;
    }
    
    public float getSaldo(){
        return saldo;
    }
    
    public void setSaldo(float saldo){
        this.saldo=saldo;
    }
    
    public float getLimitSaldo(){
        return limite_saldo;
    }
    
    public void setLimitSaldo(float limite_saldo){
        this.limite_saldo=limite_saldo;
    }
    
    public int getFechaA(){
        return fecha_apertura;
    }
    
    public void setFechaA(int fecha_apertura){
        this.fecha_apertura=fecha_apertura;
    }
    
    public String getEstado(){
        return estado;
    }
    
    public void setEstado(String estado){
        this.estado=estado;
    }
    
    @Override
    public String toString(){
        return "Cuenta{" + "ID: " + id + ", Id_Cliente: " + id_cliente + '\'' + ", Tipo: " 
                + tipo + ", Saldo: " + saldo + '\'' + ", Limite_Saldo: " 
                + limite_saldo + '\'' + ", Fecha Apertura: " + fecha_apertura + '\'' + ", Estado: " 
                + estado;
    }
}
