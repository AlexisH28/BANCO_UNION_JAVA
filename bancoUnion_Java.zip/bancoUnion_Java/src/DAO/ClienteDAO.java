/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.util.List;

/**
 *
 * @author camper
 */
public interface ClienteDAO {
    void agregarCliente(Cliente Cliente);
    Cliente obtenerCliente(int id);
    List<Cliente> obtenerTodosLosClientes();
    void actualizarCliente(Cliente nombre);
    void eliminarCliente(int id);
}
