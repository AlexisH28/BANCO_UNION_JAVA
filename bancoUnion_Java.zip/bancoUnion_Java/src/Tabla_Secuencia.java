/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Tabla_Secuencia {
    public int next_val;
     
    // Constructor para inicializar el objeto
    public Tabla_Secuencia (int next_val){
        this.next_val=next_val;               
    }
    
    public int getNextVal(){
        return next_val;
    }
    
    public void setNextVal(int next_val){
        this.next_val=next_val;
    }
    
    @Override
    public String toString(){
        return "TablaSecuencia{" + "Siguiente Valor: " + next_val;
    }
}
